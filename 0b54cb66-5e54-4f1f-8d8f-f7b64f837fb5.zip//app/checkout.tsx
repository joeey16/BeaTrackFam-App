import * as React from "react";
import { View, ScrollView, SafeAreaView, ActivityIndicator, Alert, Linking } from "react-native";
import { Text } from "~/components/ui/text";
import { Button } from "~/components/ui/button";
import { useCartContext } from "~/lib/contexts/CartContext";
import { useCart } from "~/lib/shopify/hooks";
import { useTheme } from "~/theming/ThemeProvider";
import { router } from "expo-router";
import LucideIcon from "~/lib/icons/LucideIcon";
import * as WebBrowser from "expo-web-browser";

function formatPrice(amount: string, currencyCode: string) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: currencyCode,
  }).format(parseFloat(amount));
}

export default function CheckoutScreen() {
  const { theme } = useTheme();
  const { cartId, clearCart } = useCartContext();
  const { data: cart, isLoading } = useCart(cartId);

  const handleCheckout = async () => {
    try {
      // If no cart (using mock data), redirect to the main store
      const checkoutUrl = cart?.checkoutUrl || "https://beatrackfam.info";

      // Open Shopify's checkout URL in an in-app browser
      const result = await WebBrowser.openBrowserAsync(checkoutUrl, {
        toolbarColor: theme.colors.background,
        controlsColor: theme.colors.primary,
      });

      // After checkout is complete, clear the cart
      if (result.type === "dismiss") {
        Alert.alert("Checkout", "Did you complete your purchase?", [
          {
            text: "No",
            style: "cancel",
          },
          {
            text: "Yes",
            onPress: async () => {
              await clearCart();
              router.replace("/(tabs)");
              Alert.alert("Success", "Thank you for your order!");
            },
          },
        ]);
      }
    } catch (error) {
      Alert.alert("Error", "Failed to open checkout");
    }
  };

  if (isLoading) {
    return (
      <SafeAreaView className="flex-1 bg-background">
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={theme.colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  if (!cart || cart.lines.edges.length === 0) {
    return (
      <SafeAreaView className="flex-1 bg-background">
        <View className="flex-1 items-center justify-center px-6">
          <Text className="text-h3 mb-2 text-center text-foreground">Your cart is empty</Text>
          <Button onPress={() => router.replace("/(tabs)")}>
            <Text>Continue Shopping</Text>
          </Button>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView className="flex-1 bg-background">
      <View className="flex-1">
        <ScrollView className="flex-1 px-4 pt-4" showsVerticalScrollIndicator={false}>
          {/* Header */}
          <Text className="text-h2 mb-6 font-bold text-foreground">Checkout</Text>

          {/* Info Card */}
          <View className="mb-6 rounded-2xl bg-card p-4 border border-border">
            <View className="mb-3 flex-row items-center">
              <View className="mr-3 h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                <LucideIcon name="Shield" size={20} color={theme.colors.primary} />
              </View>
              <View className="flex-1">
                <Text className="text-base font-semibold text-foreground">Secure Checkout</Text>
                <Text className="text-sm text-muted-foreground">Powered by Shopify</Text>
              </View>
            </View>
            <Text className="text-sm leading-5 text-muted-foreground">
              You'll be redirected to Shopify's secure checkout to complete your purchase with Apple
              Pay, Google Pay, or credit card.
            </Text>
          </View>

          {/* Order Summary */}
          <View className="mb-6 rounded-2xl bg-card p-4">
            <Text className="mb-3 text-lg font-semibold text-foreground">Order Summary</Text>

            <View className="mb-3 flex-row justify-between">
              <Text className="text-base text-muted-foreground">Items</Text>
              <Text className="text-base text-foreground">{cart.totalQuantity}</Text>
            </View>

            <View className="mb-3 flex-row justify-between">
              <Text className="text-base text-muted-foreground">Subtotal</Text>
              <Text className="text-base text-foreground">
                {formatPrice(
                  cart.cost.subtotalAmount.amount,
                  cart.cost.subtotalAmount.currencyCode,
                )}
              </Text>
            </View>

            {cart.cost.totalTaxAmount && (
              <View className="mb-3 flex-row justify-between">
                <Text className="text-base text-muted-foreground">Tax (estimated)</Text>
                <Text className="text-base text-foreground">
                  {formatPrice(
                    cart.cost.totalTaxAmount.amount,
                    cart.cost.totalTaxAmount.currencyCode,
                  )}
                </Text>
              </View>
            )}

            <View className="border-t border-border pt-3">
              <View className="flex-row justify-between">
                <Text className="text-lg font-semibold text-foreground">Total</Text>
                <Text className="text-xl font-bold text-primary">
                  {formatPrice(cart.cost.totalAmount.amount, cart.cost.totalAmount.currencyCode)}
                </Text>
              </View>
            </View>
          </View>

          {/* Payment Methods Info */}
          <View className="mb-6 rounded-2xl bg-muted p-4">
            <Text className="mb-2 text-sm font-semibold text-foreground">
              Accepted Payment Methods
            </Text>
            <View className="flex-row flex-wrap">
              <View className="mr-2 mb-2 flex-row items-center rounded-lg bg-background px-3 py-2">
                <LucideIcon name="Apple" size={16} color={theme.colors.foreground} />
                <Text className="ml-2 text-xs font-medium text-foreground">Apple Pay</Text>
              </View>
              <View className="mr-2 mb-2 flex-row items-center rounded-lg bg-background px-3 py-2">
                <LucideIcon name="Wallet" size={16} color={theme.colors.foreground} />
                <Text className="ml-2 text-xs font-medium text-foreground">Google Pay</Text>
              </View>
              <View className="mr-2 mb-2 flex-row items-center rounded-lg bg-background px-3 py-2">
                <LucideIcon name="CreditCard" size={16} color={theme.colors.foreground} />
                <Text className="ml-2 text-xs font-medium text-foreground">Credit Card</Text>
              </View>
            </View>
          </View>

          <View className="h-32" />
        </ScrollView>

        {/* Checkout Button */}
        <View className="border-t border-border bg-background px-4 py-4">
          <Button onPress={handleCheckout} className="w-full mb-2">
            <View className="flex-row items-center">
              <LucideIcon name="Lock" size={20} color={theme.colors.primaryForeground} />
              <Text className="ml-2">Complete Checkout</Text>
            </View>
          </Button>
          <Text className="text-center text-xs text-muted-foreground">
            By completing checkout, you agree to our terms and conditions
          </Text>
        </View>
      </View>
    </SafeAreaView>
  );
}
