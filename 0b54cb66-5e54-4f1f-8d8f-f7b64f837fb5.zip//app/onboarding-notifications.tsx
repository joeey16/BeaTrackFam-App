import * as React from "react";
import { View, SafeAreaView, Platform } from "react-native";
import { Text } from "~/components/ui/text";
import { Button } from "~/components/ui/button";
import { router, Stack } from "expo-router";

export default function NotificationPermissionScreen() {
  const [isRequesting, setIsRequesting] = React.useState(false);
  const [isNativeAvailable, setIsNativeAvailable] = React.useState(true);

  React.useEffect(() => {
    if (Platform.OS !== "ios" && Platform.OS !== "android") {
      setIsNativeAvailable(false);
    }
  }, []);

  const handleEnableNotifications = async () => {
    setIsRequesting(true);
    try {
      if (Platform.OS === "ios" || Platform.OS === "android") {
        let notificationsModule: {
          getPermissionsAsync: () => Promise<{ status: string }>;
          requestPermissionsAsync: () => Promise<{ status: string }>;
        } | null = null;

        try {
          notificationsModule = (await import("expo-notifications")) as typeof notificationsModule;
        } catch (error) {
          notificationsModule = null;
        }

        if (!notificationsModule) {
          console.log("ℹ️ Notifications module not available in this environment");
          setIsNativeAvailable(false);
          return;
        }

        const { status: existingStatus } = await notificationsModule.getPermissionsAsync();

        let finalStatus = existingStatus;
        if (existingStatus !== "granted") {
          const { status } = await notificationsModule.requestPermissionsAsync();
          finalStatus = status;
        }

        if (finalStatus === "granted") {
          console.log("✅ Notification permissions granted");
        } else {
          console.log("ℹ️ Notification permissions denied");
        }
      }
    } catch (error) {
      console.error("Failed to request notification permissions:", error);
      setIsNativeAvailable(false);
    } finally {
      setIsRequesting(false);
      router.replace("/onboarding-location");
    }
  };

  const handleSkip = () => {
    router.replace("/onboarding-location");
  };

  return (
    <SafeAreaView className="flex-1 bg-background">
      <Stack.Screen options={{ title: "Notifications" }} />
      <View className="flex-1 items-center justify-center px-8">
        {/* Title */}
        <Text className="mb-4 text-center text-3xl font-bold text-foreground">
          Order & Drop Alerts
        </Text>

        {/* Description */}
        <Text className="mb-8 text-center text-base leading-6 text-muted-foreground">
          {isNativeAvailable
            ? "Get notified about new drops, order updates, and exclusive deals. Never miss out on limited edition releases."
            : "Notifications aren’t available in this preview build. You can enable them later in your device Settings."}
        </Text>

        {/* Benefits */}
        <View className="mb-12 w-full">
          <View className="mb-4 flex-row items-start">
            <View className="flex-1">
              <Text className="mb-1 text-base font-semibold text-foreground">Order Updates</Text>
              <Text className="text-sm text-muted-foreground">Track your orders in real-time</Text>
            </View>
          </View>

          <View className="mb-4 flex-row items-start">
            <View className="flex-1">
              <Text className="mb-1 text-base font-semibold text-foreground">Exclusive Drops</Text>
              <Text className="text-sm text-muted-foreground">
                Be first to know about new releases
              </Text>
            </View>
          </View>

          <View className="flex-row items-start">
            <View className="flex-1">
              <Text className="mb-1 text-base font-semibold text-foreground">Special Offers</Text>
              <Text className="text-sm text-muted-foreground">
                Get exclusive discounts and deals
              </Text>
            </View>
          </View>
        </View>
      </View>

      {/* Bottom Buttons */}
      <View className="px-8 pb-12">
        <Button
          onPress={handleEnableNotifications}
          size="lg"
          className="mb-3 w-full"
          disabled={isRequesting || !isNativeAvailable}
        >
          <Text className="font-semibold">
            {isNativeAvailable ? "Enable Notifications" : "Notifications Unavailable"}
          </Text>
        </Button>
        <Button onPress={handleSkip} variant="ghost" size="lg" className="w-full">
          <Text className="text-muted-foreground">Skip for Now</Text>
        </Button>
      </View>
    </SafeAreaView>
  );
}
