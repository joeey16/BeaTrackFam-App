import * as AspectRatioPrimitive from "@rn-primitives/aspect-ratio";

const AspectRatio = AspectRatioPrimitive.Root;

export { AspectRatio };
